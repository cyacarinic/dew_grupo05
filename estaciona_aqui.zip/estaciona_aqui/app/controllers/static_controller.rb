class StaticController < ApplicationController
  def about
  end

  def services
  end
end
