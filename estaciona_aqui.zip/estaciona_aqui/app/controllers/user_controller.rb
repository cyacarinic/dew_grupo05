class UserController < ApplicationController
  def new
  end

  def edit
  end

  def list
  end

  def search
  end
end
